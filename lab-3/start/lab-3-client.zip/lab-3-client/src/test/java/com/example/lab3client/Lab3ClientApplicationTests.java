package com.example.lab3client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3ClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
